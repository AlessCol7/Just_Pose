# POSE > 2024-07-14 9:14am
https://universe.roboflow.com/pillpoint/pose-wgvgo

Provided by a Roboflow user
License: CC BY 4.0

