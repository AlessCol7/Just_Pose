import cv2
import os
import random
import time
from ultralytics import YOLO
import numpy as np

# Load the trained YOLO pose estimation model
model = YOLO('trained_pose_model.pt')

# Define paths
images_folder = "/Users/alessiacolumban/Just_Pose/POSE.v3i.coco (1)/images/"
annotated_images_folder = 'annotated_images'

# Create the new folder if it does not exist
os.makedirs(annotated_images_folder, exist_ok=True)

# List all image files in the images folder
image_files = [f for f in os.listdir(images_folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

# Function to calculate pose similarity
def calculate_pose_similarity(pose1, pose2):
    if pose1.shape != pose2.shape:
        return 0
    diff = np.linalg.norm(pose1 - pose2, axis=1)
    accuracy = (1 - np.mean(diff) / np.linalg.norm(np.ones_like(pose1))) * 100
    return accuracy

# Open the camera
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

last_image_time = 0
current_image = None

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error: Could not read frame.")
        break

    current_time = time.time()

    # Randomly display an image every 8 seconds
    if current_time - last_image_time > 8:
        current_image = random.choice(image_files)
        displayed_image_path = os.path.join(images_folder, current_image)
        displayed_image = cv2.imread(displayed_image_path)
        last_image_time = current_time

    # Detect pose in the camera frame
    results = model(frame, save=False)
    annotated_frame = results[0].plot()
    detected_pose = results[0].keypoints

    # Display the annotated frame and the randomly chosen image
    cv2.imshow('Camera', annotated_frame)
    if current_image is not None and displayed_image is not None:
        cv2.imshow('Target Pose', displayed_image)

    # If we have a detected pose and a displayed image with a detected pose
    if detected_pose is not None:
        displayed_results = model(displayed_image, save=False)
        displayed_pose = displayed_results[0].keypoints

        if displayed_pose is not None:
            accuracy = calculate_pose_similarity(detected_pose, displayed_pose)
            print(f"Pose accuracy: {accuracy:.2f}%")

            # If accuracy is at least 50%, take a screenshot
            if accuracy >= 50:
                screenshot_path = os.path.join(annotated_images_folder, f"screenshot_{int(current_time)}.png")
                cv2.imwrite(screenshot_path, frame)
                print(f"Screenshot saved to {screenshot_path}")

    # Exit on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
